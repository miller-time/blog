These files are all required in order to run ConnectThree.exe, so
you should extract the ConnectThree folder somewhere and create a
shortcut to the .exe file.
