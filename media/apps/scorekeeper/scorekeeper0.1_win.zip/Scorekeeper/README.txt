Scorekeeper 0.1

Author: Russell Miller

.dll files what??
-----------------
These files are all required in order to run Scorekeeper.exe, so
 after extracting them keep the Scorekeeper.exe file in the same folder and create a 
shortcut to it.


To do:
-----------------
- deal with tie games...
- add ascending/descending to Options screen.
- when declaring winner check whether score is ascending
- possibly sort players on main window by score?