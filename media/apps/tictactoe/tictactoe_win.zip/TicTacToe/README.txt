These files are all required in order to run TicTacToe.exe, so
you should extract the TicTacToe folder somewhere and create a
shortcut to the .exe file.
